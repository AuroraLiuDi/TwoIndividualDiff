import random
import tempfile
import time
from typing import List, Union

from dallinger import db
from markupsafe import Markup
from sqlalchemy import Column, ForeignKey, Integer
from sqlalchemy.orm import relationship

import psynet.experiment
from psynet.asset import DebugStorage, ExperimentAsset
from psynet.bot import Bot
from psynet.consent import NoConsent, MainConsent
from psynet.data import SQLBase, SQLMixin, register_table
from psynet.demography.general import ExperimentFeedback
from psynet.modular_page import ModularPage, Prompt, PushButtonControl, SliderControl
from psynet.page import InfoPage, SuccessfulEndPage
from psynet.participant import Participant
from psynet.process import AsyncProcess
from psynet.timeline import Event, CodeBlock, Timeline
from psynet.trial.gibbs import GibbsNetwork, GibbsNode, GibbsTrial, GibbsTrialMaker
from psynet.trial.main import TrialNode
from psynet.utils import get_logger

logger = get_logger()

TARGETS = ["happy","happy"]
CHERNOFF = ["face", "hair", "mouth",  "nosew", "noseh", "eyew", "eyeh", "brow"]
DIMENSION_NAMES = ["f", "h", "m", "nw", "nh", "ew", "eh", "b"]
DIMENSION_MAX = [1, 1, 1, 1, 1, 1, 1, 1]
DIMENSION_MAX = list(map(int, DIMENSION_MAX))
DIMENSION_MIN = [0, -1, -1, 0, 0, 0, 0, 0]
DIMENSION_MIN = list(map(int, DIMENSION_MIN))

class FacePrompt(Prompt):
    macro = "face_prompt"
    external_template = "face_prompt.html"

    def __init__(
            self,
            definition,
            prompt: Union[str, Markup],
            selected_idx: int,
            text_align: str = "center",
            **kwargs
    ):
        assert selected_idx >= 0 and selected_idx < len(CHERNOFF)
        self.selected_idx = selected_idx
        self.prompt = prompt

        super().__init__(Prompt(prompt), text_align=text_align, **kwargs)
        self.definition = definition

        @property
        def metadata(self):
            return {
                **super().metadata,
                "definition": self.definition,
                "selected_idx": self.selected_idx,
            }

class CustomNetwork(GibbsNetwork):
    run_async_post_grow_network = True


class CustomNode(GibbsNode):
    vector_length = 8

    def random_sample(self, i):
        return random.uniform(DIMENSION_MIN[i], DIMENSION_MAX[i])

class CustomTrial(GibbsTrial):
    # If True, then the starting value for the free parameter is resampled
    # on each trial.
    run_async_post_trial = False
    resample_free_parameter = False
    time_estimate = 5
    def show_trial(self, experiment, participant):
        target = self.context["target"]
        current_state = self.definition["vector"]
        face_dict = {}
        for name, val in zip(DIMENSION_NAMES, current_state):
            face_dict[name] = val

        prompt = Markup(
            "<p>Adjust the slider to the point where you are <strong> most uncertain </strong> about whether the face is "
            f"{target}</p>"
        )
        page = ModularPage(
            "custom_trial",
            FacePrompt(
                face_dict,
                prompt,
                text_align="center",
                selected_idx=self.active_index),
            SliderControl(
                start_value=current_state[self.active_index],
                min_value=DIMENSION_MIN[self.active_index],
                max_value=DIMENSION_MAX[self.active_index],
                minimal_interactions=1,
		continuous_updates=True,
		),
            time_estimate=5,
            events={
                "createFace": Event(
                    is_triggered_by="trialConstruct",
                    js=f"""
                        var slider = document.querySelector('input[type=range]');
                        slider.addEventListener('input', function() {{
                            dat[0]['{DIMENSION_NAMES[self.active_index]}'] = this.value;
                            create_face(dat);
                        }});
                    """,
                ),
            }
        )
        return [
            page,
            # You can also include code blocks within a trial.
            # This one doesn't do anything useful, it's just there for demonstration purposes.
            CodeBlock(lambda participant: participant.var.set("test_variable", 123)),
        ]

    def async_post_trial(self):
        # You could put a time-consuming analysis here, perhaps one that generates a plot...
        time.sleep(1)
        self.var.async_post_trial_completed = True
        with tempfile.NamedTemporaryFile("w") as file:
            file.write(f"completed async_post_trial for trial {self.id}")
            file.flush()
            asset = ExperimentAsset(
                local_key="async_post_trial",
                input_path=file.name,
                extension=".txt",
                parent=self,
            )
            asset.deposit()




class CustomTrialMaker(GibbsTrialMaker):
    give_end_feedback_passed = False
    performance_threshold = -1.0

    # If we set this to True, then the performance check will wait until all async_post_trial processes have finished
    end_performance_check_waits = False

    def prioritize_networks(self, networks, participant, experiment):
        for network in networks:
            network.alive_trials_at_degree = len(
                TrialNode.query.filter_by(network_id=network.id)
                .order_by(TrialNode.id)
                .all()[-1]
                .alive_trials
            )

        # Prioritize nodes with the most alive trials
        return list(reversed(sorted(networks, key=lambda n: n.alive_trials_at_degree)))

    def get_end_feedback_passed_page(self, score):
        score_to_display = "NA" if score is None else f"{(100 * score):.0f}"

        return InfoPage(
            Markup(
                f"Your consistency score was <strong>{score_to_display}&#37;</strong>."
            ),
            time_estimate=5,
        )

    def compute_bonus(self, score, passed):
        if score is None:
            return 0.0
        else:
            return max(0.0, score)

    def custom_network_filter(self, candidates, participant):
        # As an example, let's make the participant join networks
        # in order of increasing network ID.
        return sorted(candidates, key=lambda x: x.id)


start_nodes = [
    CustomNode(context={"target": target, "chernoff": chernoff})
    for target in TARGETS
    for chernoff in CHERNOFF
]

trial_maker = CustomTrialMaker(
    id_="face_gibbs",
    start_nodes=start_nodes,
    network_class=CustomNetwork,
    trial_class=CustomTrial,
    node_class=CustomNode,
    chain_type="across",  # can be "within" or "across"
    expected_trials_per_participant=16,
    max_trials_per_participant=16,
    max_nodes_per_chain=80,
    chains_per_participant=None,  # set to None if chain_type="across"
    chains_per_experiment=16,  # set to None if chain_type="within"
    trials_per_node=1,
    balance_across_chains=True,
    check_performance_at_end=True,
    check_performance_every_trial=False,
    propagate_failure=False,
    recruit_mode="n_trials",
    target_n_participants=None,
    n_repeat_trials=3,
    wait_for_networks=True,  # wait for asynchronous processes to complete before continuing to the next trial
    #choose_participant_group=lambda participant: participant.var.participant_group,
)


###################
# This code is borrowed from the custom_table_simple demo.
# It is totally irrelevant for the Gibbs implementation.
# We just include it so we can test the export functionality
# in the regression tests.
@register_table
class Coin(SQLBase, SQLMixin):
    __tablename__ = "coin"

    participant = relationship(Participant, backref="all_coins")
    participant_id = Column(Integer, ForeignKey("participant.id"), index=True)

    def __init__(self, participant):
        self.participant = participant
        self.participant_id = participant.id


def collect_coin():
    return CodeBlock(_collect_coin)


def _collect_coin(participant):
    coin = Coin(participant)
    coin.var.test = "123"
    db.session.add(coin)


class Exp(psynet.experiment.Experiment):
    label = "Face Gibbs"
    # asset_storage = DebugStorage()
    initial_recruitment_size = 1
    variables = {
        "max_participant_payment": 2.0,
    }
    timeline = Timeline(
        MainConsent(),
        InfoPage(
            Markup("""
            <h1>Instructions</h1>
            <hr>
            <p>
            Some faces look really happy. Some faces look really sad. Others look angry or surprised…
            But for some faces you're not really sure. They are ambiguous.
            In this study, we're interested in ambiguous faces where you're not sure whether it's happy or not.
            You'll be asked to adjust the slider to find faces where you feel most uncertain.
            </p>
            <hr>
            """),
            time_estimate=10
        ),
        trial_maker,
        collect_coin(),
        ExperimentFeedback(),
        SuccessfulEndPage(),
    )

    test_n_bots = 4

    def test_check_bots(self, bots: List[Bot]):
        time.sleep(2.0)

        #assert len([b for b in bots if b.var.participant_group == "A"]) == 2
        #assert len([b for b in bots if b.var.participant_group == "B"]) == 2

        for b in bots:
            assert len(b.alive_trials) == 7  # 4 normal trials + 3 repeat trials
            assert all([t.finalized for t in b.alive_trials])

        processes = AsyncProcess.query.all()
        assert all([not p.failed for p in processes])

        super().test_check_bots(bots)
