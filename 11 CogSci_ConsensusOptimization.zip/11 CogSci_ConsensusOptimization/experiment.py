import random
import tempfile
import time
import numpy as np
import rpdb
from typing import List, Union

from dallinger import db
from markupsafe import Markup
from sqlalchemy import Column, ForeignKey, Integer
from sqlalchemy.orm import relationship

import psynet.experiment
from psynet.asset import DebugStorage, ExperimentAsset
from psynet.bot import Bot
from psynet.consent import NoConsent, MainConsent
from psynet.data import SQLBase, SQLMixin, register_table
from psynet.demography.general import ExperimentFeedback
from psynet.modular_page import ModularPage, Prompt, PushButtonControl, SliderControl
from psynet.page import InfoPage, SuccessfulEndPage
from psynet.participant import Participant
from psynet.process import AsyncProcess
from psynet.timeline import Event, CodeBlock, Timeline
from psynet.trial.gibbs import GibbsNetwork, GibbsNode, GibbsTrial, GibbsTrialMaker
from psynet.trial.main import TrialNode
from psynet.utils import get_logger
from psynet.trial.main import Trial

logger = get_logger()

TARGETS = ["happy"]
CHERNOFF = ["face", "hair", "mouth",  "nosew", "noseh", "eyew", "eyeh", "brow"]
DIMENSION_NAMES = ["f", "h", "m", "nw", "nh", "ew", "eh", "b"]
DIMENSION_MAX = [1, 1, 1, 1, 1, 1, 1, 1]
DIMENSION_MAX = list(map(int, DIMENSION_MAX))
DIMENSION_MIN = [0, -1, -1, 0, 0, 0, 0, 0]
DIMENSION_MIN = list(map(int, DIMENSION_MIN))
RESOLUTION = 5

class FacePrompt(Prompt):
    macro = "face_prompt"
    external_template = "face_prompt.html"

    def __init__(
            self,
            definition,
            prompt: Union[str, Markup],
            selected_idx: int,
            text_align: str = "center",
            **kwargs
    ):
        assert selected_idx >= 0 and selected_idx < len(CHERNOFF)
        self.selected_idx = selected_idx
        self.prompt = prompt

        super().__init__(Prompt(prompt), text_align=text_align, **kwargs)
        self.definition = definition

        @property
        def metadata(self):
            return {
                **super().metadata,
                "definition": self.definition,
                "selected_idx": self.selected_idx,
            }

class CustomNetwork(GibbsNetwork):
    run_async_post_grow_network = True


class CustomNode(GibbsNode):
    vector_length = 8

    def random_sample(self, i):
        return random.uniform(DIMENSION_MIN[i], DIMENSION_MAX[i])

    def create_candidates(self, vector, active_index):
        edits = np.linspace(DIMENSION_MIN[active_index], DIMENSION_MAX[active_index], RESOLUTION)
        candidates = []
        for e in edits:
            new_candidate = vector.copy()
            new_candidate[active_index] = e
            candidates = candidates + [new_candidate]
        return candidates

    def balance_candidates(self): # propose the candidate with least judgments
        num_candidates = len(self.definition["candidates"])
        all_viable_trials = self.get_viable_trials()
        for trial in all_viable_trials:
            print(f"Trial: {trial}")
            print("definition")
            print(trial.definition)

        print(f"Node Definition: {self.definition}")

        # Initialize a counter for candidate assignments
        candidate_counters = np.zeros(num_candidates)

        # Process viable trials
        for trial in all_viable_trials:
            if trial.definition and "candidate_idx" in trial.definition:
                # Count valid assignments
                candidate_idx = trial.definition["candidate_idx"]
                candidate_counters[candidate_idx] += 1
            else:
                print(f"Trial {trial} has no valid definition. Skipping for now.")

        # Identify candidates with fewer than 2 assignments
        viable_candidates = np.where(candidate_counters < 2)[0]

        # If all candidates have at least 2 assignments, pick the least assigned ones
        if len(viable_candidates) == 0:
            min_count = min(candidate_counters)
            viable_candidates = np.where(candidate_counters == min_count)[0]

        # Randomly choose from the viable candidates
        selected_candidate = int(random.choice(viable_candidates))
        print(f"Selected Candidate: {selected_candidate}")
        return selected_candidate

    def get_viable_trials(self):
        return Trial.query.filter_by(
            origin_id=self.id, failed=False, is_repeat_trial=False
        ).all()

    def create_definition_from_seed(self, seed, experiment, participant):  # add a counter to manage candidates
        vector = seed["vector"]
        dimension = len(vector)
        required_keys = ["active_index"]
        print("seed", seed)
        for key in required_keys:
            if key not in seed:
                original_index = seed["initial_index"]
            else:
                original_index = seed["active_index"]
        new_index = (original_index + 1) % dimension
        candidates = self.create_candidates(vector, new_index)
        canditates_counter = [0 for _ in candidates]
        return {"vector": vector, "active_index": new_index, "candidates": candidates}
        # return {"vector": vector, "active_index": new_index, "candidates": candidates, "candidates_counter": canditates_counter}

        # def reached_target_num_trials(self):
        #     return self.completed_and_processed_trials.count() >= self.target_num_trials

    def compute_cadidate_score(self, observations):
        return np.mean(observations)

    def summarize_trials(self, trials: list, experiment, participant):
        self.var.summarize_trials_used = [t.id for t in trials]
        active_index = trials[0].active_index
        candidates = self.definition["candidates"]
        num_candidates = len(candidates)
        candidate_scores = [0 for _ in range(num_candidates)]
        candidate_counters = [0 for _ in range(num_candidates)]
        for t in trials:
            print(f"Trial: {t}, Answer: {t.answer}, Definition: {t.definition}")

        for i in range(num_candidates):
            observations = [float(t.answer.get('custom_trial')) for t in trials if t.definition["candidate_idx"] == i]
            candidate_scores[i] = self.compute_cadidate_score(observations)
            candidate_counters[i] = len(observations)
        #try:
        print("observations: ", observations)
        summary = int(random.choice(np.where(np.array(candidate_scores) == max(candidate_scores))[0]))
        #except:
            #rpdb.set_trace()
        self.var.summarize_trials_output = summary

        vector = candidates[summary]
        return {"vector": vector, "active_index": active_index}


class CustomTrial(GibbsTrial):
    # If True, then the starting value for the free parameter is resampled
    # on each trial.
    run_async_post_trial = False
    resample_free_parameter = False
    time_estimate = 5
    accumulate_answers = True

    def make_definition(self, experiment, participant):
        candidates = self.node.definition["candidates"]
        candidate_idx = self.node.balance_candidates()
        vector = candidates[candidate_idx].copy()
        active_index = self.node.definition["active_index"]
        reverse_scale = self.choose_reverse_scale()

        # if self.resample_free_parameter:
        #     vector[active_index] = self.network.random_sample(active_index)

        definition = {
            "vector": vector,
            "active_index": active_index,
            "candidate": vector,
            "candidate_idx": candidate_idx,
            "reverse_scale": reverse_scale,
        }

        return definition

    def show_trial(self, experiment, participant):
        target = self.context["target"]
        current_state = self.definition["vector"]
        face_dict = {}

        for name, val in zip(DIMENSION_NAMES, current_state):
            face_dict[name] = val

        prompt = Markup(
            "<p>How well does the face fit the following word: "
            f"<p><strong>{target}</strong></p>"
        )

        new_face_dict = face_dict.copy()

        page = ModularPage(
            "custom_trial",
            FacePrompt(
                new_face_dict,
                prompt,
                text_align="center",
                selected_idx=self.active_index),
            PushButtonControl(
                choices=[i for i in range(1,8)],
                labels=[
                    "(1) Completely disagree",
                    "(2) Strongly disagree",
                    "(3) Somewhat disagree",
                    "(4) Neither agree nor disagree",
                    "(5) Somewhat agree",
                    "(6) Strongly agree",
                    "(7) Completely agree"
                    ],
                arrange_vertically=True
                ),
            time_estimate=3,
        )
        return [
            page
        ]

    def async_post_trial(self):
        # You could put a time-consuming analysis here, perhaps one that generates a plot...
        time.sleep(1)
        self.var.async_post_trial_completed = True
        with tempfile.NamedTemporaryFile("w") as file:
            file.write(f"completed async_post_trial for trial {self.id}")
            file.flush()
            asset = ExperimentAsset(
                local_key="async_post_trial",
                input_path=file.name,
                extension=".txt",
                parent=self,
            )
            asset.deposit()




class CustomTrialMaker(GibbsTrialMaker):
    give_end_feedback_passed = False
    performance_threshold = -1.0

    # If we set this to True, then the performance check will wait until all async_post_trial processes have finished
    end_performance_check_waits = False

    def prioritize_networks(self, networks, participant, experiment):
        for network in networks:
            network.alive_trials_at_degree = len(
                TrialNode.query.filter_by(network_id=network.id)
                .order_by(TrialNode.id)
                .all()[-1]
                .alive_trials
            )

        # Prioritize nodes with the most alive trials
        return list(reversed(sorted(networks, key=lambda n: n.alive_trials_at_degree)))

    def get_end_feedback_passed_page(self, score):
        score_to_display = "NA" if score is None else f"{(100 * score):.0f}"

        return InfoPage(
            Markup(
                f"Your consistency score was <strong>{score_to_display}&#37;</strong>."
            ),
            time_estimate=5,
        )

    def compute_bonus(self, score, passed):
        if score is None:
            return 0.0
        else:
            return max(0.0, score)

    def custom_network_filter(self, candidates, participant):
        # As an example, let's make the participant join networks
        # in order of increasing network ID.
        return sorted(candidates, key=lambda x: x.id)

start_nodes = [
    CustomNode(
        context={"target": target, "chernoff": chernoff},
    )
    for target in TARGETS
    for chernoff in CHERNOFF
]

trial_maker = CustomTrialMaker(
    id_="optimizer_custom",
    start_nodes=start_nodes,
    network_class=CustomNetwork,
    trial_class=CustomTrial,
    node_class=CustomNode,
    chain_type="across",  # can be "within" or "across"
    expected_trials_per_participant=5,
    max_trials_per_participant=5,
    max_nodes_per_chain=8 * 10,
    chains_per_participant=None,  # set to None if chain_type="across"
    chains_per_experiment=8,  # set to None if chain_type="within"
    trials_per_node=RESOLUTION * 2,
    balance_across_chains=True,
    check_performance_at_end=False,
    check_performance_every_trial=False,
    propagate_failure=False,
    recruit_mode="n_trials",
    target_n_participants=None,
    n_repeat_trials=2,
    wait_for_networks=True,
    allow_revisiting_networks_in_across_chains=False# wait for asynchronous processes to complete before continuing to the next trial
    #choose_participant_group=lambda participant: participant.var.participant_group,
)

###################
# This code is borrowed from the custom_table_simple demo.
# It is totally irrelevant for the Gibbs implementation.
# We just include it so we can test the export functionality
# in the regression tests.
@register_table
class Coin(SQLBase, SQLMixin):
    __tablename__ = "coin"

    participant = relationship(Participant, backref="all_coins")
    participant_id = Column(Integer, ForeignKey("participant.id"), index=True)

    def __init__(self, participant):
        self.participant = participant
        self.participant_id = participant.id


def collect_coin():
    return CodeBlock(_collect_coin)


def _collect_coin(participant):
    coin = Coin(participant)
    coin.var.test = "123"
    db.session.add(coin)


class Exp(psynet.experiment.Experiment):
    label = "Face Gibbs"
    # asset_storage = DebugStorage()
    initial_recruitment_size = 1
    variables = {
        "max_participant_payment": 2.0,
    }
    timeline = Timeline(
        MainConsent(),
        InfoPage(
            Markup("""
            <h1>Instructions</h1>
            <hr>
            <p>
                In this experiment, we study how people perceive cartoon faces.
                On each trial, you will see a cartoon face and a slider. Moving the slider will change a part of the face (e.g. the nose or mouth). 
                Please move the slider until it looks as happy as possible.
            </p>
            <hr>
            """),
            time_estimate=10
        ),
        trial_maker,
        collect_coin(),
        ExperimentFeedback(),
        SuccessfulEndPage(),
    )

    test_n_bots = 4

    def test_check_bots(self, bots: List[Bot]):
        time.sleep(2.0)

        #assert len([b for b in bots if b.var.participant_group == "A"]) == 2
        #assert len([b for b in bots if b.var.participant_group == "B"]) == 2

        for b in bots:
            assert len(b.alive_trials) == 7  # 4 normal trials + 3 repeat trials
            assert all([t.finalized for t in b.alive_trials])

        processes = AsyncProcess.query.all()
        assert all([not p.failed for p in processes])

        super().test_check_bots(bots)
