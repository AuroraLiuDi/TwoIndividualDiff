# pylint: disable=unused-import,abstract-method,unused-argument,no-member

##########################################################################################
# Imports
##########################################################################################
import numpy as np
import random
from typing import List, Union

from dallinger import db
from flask import Markup
from sqlalchemy import Column, ForeignKey, Integer
from sqlalchemy.orm import relationship
import rpdb

import psynet.experiment
from psynet.trial.main import Trial
from psynet.consent import MainConsent
from psynet.data import SQLBase, SQLMixin, register_table
from psynet.modular_page import ModularPage, PushButtonControl, SliderControl, NumberControl, TextControl
from psynet.page import InfoPage, Prompt, SuccessfulEndPage
from psynet.participant import Participant
from psynet.timeline import CodeBlock, Timeline, Event, join
from psynet.trial.gibbs import (
    GibbsNetwork,
    GibbsNode,
    GibbsSource,
    GibbsTrial,
    GibbsTrialMaker,
)
from psynet.utils import get_logger
from psynet.prescreen import LexTaleTest
logger = get_logger()

TARGETS = ["happy"]
CHERNOFF = ["face", "hair", "mouth",  "nosew", "noseh", "eyew", "eyeh", "brow"]
DIMENSION_NAMES = ["f", "h", "m", "nw", "nh", "ew", "eh", "b"]
DIMENSION_RANGE = [[0, 1], [-1, 1], [-1, 1], [0, 1], [0, 1], [0, 1], [0, 1], [-1, 1]]
NUM_TRIALS_PER_PARTICIPANT = 2 * 1 * 10 * 10
NUM_ITERATIONS_PER_CHAIN = 2 * 10
NUM_CHAINS_PER_EXPERIMENT = 2
RESOLUTION = 5
TARGET_JUDGMENTS_PER_CANDIDATE = 2 # replaces trials_per_node
ALLOW_REVISITING_NETWORKS_IN_ACROSS_CHAINS = True
NUM_REPEAT_TRIALS = 5

class FacePrompt(Prompt):
    macro = "face_prompt"
    external_template = "face_prompt.html"

    def __init__(
            self,
            definition,
            prompt: Union[str, Markup],
            selected_idx: int,
            text_align: str = "center",
            **kwargs
    ):
        assert selected_idx >= 0 and selected_idx < len(CHERNOFF)
        self.selected_idx = selected_idx
        self.prompt = prompt

        super().__init__(Prompt(prompt), text_align=text_align, **kwargs)
        self.definition = definition

        @property
        def metadata(self):
            return {
                **super().metadata,
                "definition": self.definition,
                "selected_idx": self.selected_idx,
            }


class CustomNetwork(GibbsNetwork):
    vector_length = 8

    def random_sample(self, i):
        return random.uniform(DIMENSION_RANGE[i][0], DIMENSION_RANGE[i][1])

    def make_definition(self):
        return {
            "target": self.balance_across_networks(TARGETS)
        }

    # if self.balance_across_chains:
    #     networks.sort(key=lambda network: network.num_completed_trials)

class CustomTrial(GibbsTrial):
    accumulate_answers = True
    # resample_free_parameter = False
    time_estimate = 4

    def make_definition(self, experiment, participant):
        candidates = self.node.definition["candidates"]
        candidate_idx = self.node.balance_candidates()
        vector = candidates[candidate_idx].copy()
        active_index = self.node.definition["active_index"]
        reverse_scale = self.choose_reverse_scale()

        # if self.resample_free_parameter:
        #     vector[active_index] = self.network.random_sample(active_index)

        definition = {
            "vector": vector,
            "active_index": active_index,
            "candidate": vector,
            "candidate_idx": candidate_idx,
            "reverse_scale": reverse_scale,
        }

        return definition

    def show_trial(self, experiment, participant):

        target = self.network.definition["target"]
        current_state = self.definition["vector"]
        face_dict = {}

        for name, val in zip(DIMENSION_NAMES, current_state):
            face_dict[name] = val

        # all_pages=[]
        prompt = Markup(
            "<p>How well does the face fit the following word: "
            f"<p><strong>{target}</strong></p>"
        )

        new_face_dict = face_dict.copy()

        page = ModularPage(
            "custom_trial",
            FacePrompt(
                new_face_dict,
                prompt,
                text_align="center",
                selected_idx=self.active_index
            ),
            PushButtonControl(
                choices=[i for i in range(1,8)],
                labels=[
                    "(1) Completely disagree",
                    "(2) Strongly disagree",
                    "(3) Somewhat disagree",
                    "(4) Neither agree nor disagree",
                    "(5) Somewhat agree",
                    "(6) Strongly agree",
                    "(7) Completely agree"
                    ],
                arrange_vertically=False
                ),
            time_estimate=3,
            )

        return [page]


class CustomNode(GibbsNode):
    def create_candidates(self, vector, active_index):
        edits = np.linspace(DIMENSION_RANGE[active_index][0], DIMENSION_RANGE[active_index][1], RESOLUTION)
        candidates = []
        for e in edits:
            new_candidate = vector.copy()
            new_candidate[active_index] = e
            candidates = candidates + [new_candidate]
        return candidates

    def balance_candidates(self): # propose the candidate with least judgments
        num_candidates = len(self.definition["candidates"])
        all_viable_trials = self.get_viable_trials()
        trials_with_idx = [t for t in all_viable_trials if "candidate_idx" in t.definition]
        assignments = np.array([t.definition["candidate_idx"] for t in trials_with_idx])

        if len(assignments) == 0:
            return random.choice([i for i in range(num_candidates)])

        viable_candidates_counter = np.zeros(num_candidates)
        for i in range(num_candidates):
            viable_candidates_counter[i] = np.sum(assignments == i) # count all non-failed candidate assignments

        return int(random.choice(np.where(viable_candidates_counter == min(viable_candidates_counter))[0])) 

    def create_definition_from_seed(self, seed, experiment, participant): # add a counter to manage candidates
        vector = seed["vector"]
        dimension = len(vector)
        original_index = seed["active_index"]
        new_index = (original_index + 1) % dimension
        candidates = self.create_candidates(vector, new_index)
        canditates_counter = [0 for _ in candidates]
        return {"vector": vector, "active_index": new_index, "candidates": candidates}
        # return {"vector": vector, "active_index": new_index, "candidates": candidates, "candidates_counter": canditates_counter}

    def get_viable_trials(self):
        return Trial.query.filter_by(
            origin_id=self.id, failed=False, is_repeat_trial=False
        ).all()
    
    # def reached_target_num_trials(self):
    #     return self.completed_and_processed_trials.count() >= self.target_num_trials

    def compute_cadidate_score(self, observations):
        return np.mean(observations)

    def summarize_trials(self, trials: list, experiment, participant):
        self.var.summarize_trials_used = [t.id for t in trials]
        active_index = trials[0].active_index
        candidates = self.definition["candidates"]
        num_candidates = len(candidates)
        candidate_scores = [0 for _ in range(num_candidates)]
        candidate_counters = [0 for _ in range(num_candidates)]

        for i in range(num_candidates):
            observations = [float(t.answer[0]) for t in trials if t.definition["candidate_idx"] == i]
            candidate_scores[i] = self.compute_cadidate_score(observations)
            candidate_counters[i] = len(observations)

        try:
            summary = int(random.choice(np.where(np.array(candidate_scores) == max(candidate_scores))[0]))
        except:
            rpdb.set_trace()
        self.var.summarize_trials_output = summary

        vector = candidates[summary]
        return {"vector": vector, "active_index": active_index}


class CustomSource(GibbsSource):
    pass


class CustomTrialMaker(GibbsTrialMaker):
    give_end_feedback_passed = False
    performance_threshold = -1.0
    performance_check_type = "consistency"

    def get_end_feedback_passed_page(self, score):
        score_to_display = "NA" if score is None else f"{(100 * score):.0f}"

        return InfoPage(
            Markup(
                f"Your consistency score was <strong>{score_to_display}&#37;</strong>."
            ),
            time_estimate=5,
        )

    def compute_bonus(self, score, passed):
        if score is None:
            return 0.0
        else:
            return min(max(0.0, score), 0.2)


# Experiment trials
trial_maker_experiment = CustomTrialMaker(
    id_="optimizer_experiment",
    network_class=CustomNetwork,
    trial_class=CustomTrial,
    node_class=CustomNode,
    source_class=CustomSource,
    phase="experiment",  # can be whatever you like
    chain_type="across",  # can be "within" or "across"
    num_trials_per_participant=NUM_TRIALS_PER_PARTICIPANT,
    num_iterations_per_chain=NUM_ITERATIONS_PER_CHAIN,
    num_chains_per_participant=None,  # set to None if chain_type="across"
    num_chains_per_experiment=NUM_CHAINS_PER_EXPERIMENT,  # set to None if chain_type="within"
    trials_per_node= RESOLUTION * TARGET_JUDGMENTS_PER_CANDIDATE,
    balance_across_chains=True,
    check_performance_at_end=False,
    check_performance_every_trial=False,
    propagate_failure=False,
    recruit_mode="num_trials",
    target_num_participants=None,
    num_repeat_trials=NUM_REPEAT_TRIALS,
    allow_revisiting_networks_in_across_chains=ALLOW_REVISITING_NETWORKS_IN_ACROSS_CHAINS # I think it's ok to reparticipate as a rater
)

instructions_training = join(
    InfoPage(
        Markup("""
        <h1>Instructions</h1>
        <hr>
        <p>
            In this experiment, we study how people perceive cartoon faces.
            In particular, you will see different cartoon faces and rate them depending
            on how well they fit a certain word in question.
        </p>
        <hr>
        """),
        time_estimate=10
    ),
    InfoPage(
        Markup("""
        <h1>Instructions (cont.):</h1>
        <h3>
            You will have seven response options ranging from "(1) completely disagree" to "(7) completely agree".
        </h3>
        <hr>
        <p>
            <strong>Note:</strong> The quality of your responses will be checked automatically,
            and high quality responses will be bonused accordingly at the end of the experiment.
            The best strategy is to perform the task honestly and carefully, and then you will tend to give good results.
        </p>
        <hr>
        """),
        time_estimate=10
    )
)

instructions_experiment = InfoPage(
    Markup("""
    <h1>Instructions (cont.):</h1>
    <h3>
        The experiment will begin now. Pay careful attention to the various faces!
        Sometimes the differences can be subtle, choose what seems most accurate to you.
    </h3>
    <p>
        <strong>Remember:</strong> the best strategy is just to honestly report what you think fits better!
    </p>
    """),
    time_estimate=3
)

demographics = join(
    InfoPage("You reached the end of the experiment! Before we finish, we need to ask some quick questions about you.", time_estimate=5), 
    ModularPage(
        "age",
        Prompt("Please indicate your age in years."),
        control=NumberControl(),
        time_estimate=3,
    ),
    ModularPage(
        "gender",
        Prompt("What gender do you identify as?"),
        control=PushButtonControl(
            ["Female", "Male", "Other"], arrange_vertically=False
        ),
        time_estimate=3,
    ),
    ModularPage(
        "education",
        Prompt("What is your highest educational qualification?"),
        control=PushButtonControl(
            [
                "None",
                "Elementary school",
                "Middle school",
                "High school",
                "University Undergraduate",
                "University Graduate",
                "University PhD"
            ],
            arrange_vertically=False,
        ),
        time_estimate=3,
    ),
    ModularPage(
        "country",
        Prompt(
            """
            What country are you from?
            """
        ),
        control=TextControl(one_line=True),
        time_estimate=3,
    ),
    ModularPage(
        "mother_tongue",
        Prompt(
            """
            What is your first language?
            """
        ),
        control=TextControl(one_line=True),
        time_estimate=3,
    )
)

final_questionnaire = join(
    ModularPage(
        "strategy",
        Prompt(
            """
        Please tell us in a few words about your experience taking the task.
        What was your strategy?
        Did you find the task easy or difficult?
        Did you find it interesting or boring?
        """
        ),
        control=TextControl(one_line=False),
        time_estimate=10,
    ),
    ModularPage(
        "technical",
        Prompt(
            """
        Did you experience any technical problems during the task?
        If so, please describe them.
        """
        ),
        control=TextControl(one_line=False),
        time_estimate=10,
    ),
)



##########################################################################################
# Experiment
##########################################################################################


# Weird bug: if you instead import Experiment from psynet.experiment,
# Dallinger won't allow you to override the bonus method
# (or at least you can override it but it won't work).
class Exp(psynet.experiment.Experiment):
    timeline = Timeline(
        MainConsent(),
        #LexTaleTest(),
        #instructions_training,
        #instructions_experiment,
        trial_maker_experiment,
        demographics,
        final_questionnaire,
        InfoPage(Markup(
            """
            <strong>Attention</strong>: If you experience any problems in submitting the HIT, don't worry, just send us
            an email <strong>directly at computational.audition+online_running@gmail.com</strong> with your accurate worker id and bonus.
            Please avoid using the automatic error boxes. This will help us compensate you appropriately.
            """
        ),time_estimate=5),
        SuccessfulEndPage(),
    )

    def __init__(self, session=None):
        super().__init__(session)

        # Change this if you want to simulate multiple simultaneous participants.
        self.initial_recruitment_size = 30
